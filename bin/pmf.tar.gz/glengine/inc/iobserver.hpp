
#ifndef _IOBSERVER_
#define _IOBSERVER_

class IObserver
{
public:
    virtual void update() = 0;
};

#endif