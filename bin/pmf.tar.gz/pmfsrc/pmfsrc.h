#ifndef pmfsrc_H
#define pmfsrc_H

#include <QtGui/QMainWindow>

class pmfsrc : public QMainWindow
{
Q_OBJECT
public:
    pmfsrc();
    virtual ~pmfsrc();
};

#endif // pmfsrc_H
