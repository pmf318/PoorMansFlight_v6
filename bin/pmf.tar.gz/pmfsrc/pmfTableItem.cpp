#include "pmfTableItem.h"




void PmfTableItem::deb(GString msg)
{
    printf("PmfTableItem> %s\n", (char*)msg);
}
